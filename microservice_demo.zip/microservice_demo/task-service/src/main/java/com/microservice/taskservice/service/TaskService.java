package com.microservice.taskservice.service;

import com.microservice.taskservice.entities.Category;
import com.microservice.taskservice.entities.Task;
import com.microservice.taskservice.repository.CategoryRepository;
import com.microservice.taskservice.repository.TaskRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.transaction.Transactional;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


@RestController
@RefreshScope
public class TaskService {


    private final Logger logger = LoggerFactory.getLogger(TaskService.class);

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private CategoryRepository categoryRepository;



    //for dynamic config cloud bus
    @Value("${application.version}")
    private String applicationVersion;

    @GetMapping("application/version")
    public String applicationVersion() {
        return applicationVersion;
    }
   //for dynamic config cloud bus

//    @PostMapping("task")
//    @Transactional
//    public ResponseEntity<Task> addTasks(@RequestBody Task task){
//        logger.info("Task {}" ,task);
//        Set<Category> categories=task.getCategories();
//        Set<Category> taskCategories= new HashSet<>();
//
//        for (Category category : categories) {
//            Category existingCategory = categoryRepository.findByName(category.getName());
//            if (existingCategory == null) {
//                existingCategory = categoryRepository.save(category);
//                taskCategories.add(existingCategory);
//            }
//            existingCategory.setTasks(new HashSet<>());
//            taskCategories.add(existingCategory);
//        }
//        task.setCategories(taskCategories);
//        Task savedTask= taskRepository.save(task);
//        return new ResponseEntity<Task>(savedTask, HttpStatus.CREATED);
//    }

    @PostMapping("task")
    @Transactional
    public ResponseEntity<Task> addTasks(@RequestBody Task task){
        logger.info("Task {}" ,task);
        Set<Category> categories=task.getCategories();
        Set<Category> taskCategories= new HashSet<>();

        categories.stream().forEach(category -> {
        Category existingCategory = categoryRepository.findByName(category.getName());
            if (existingCategory == null) {
                existingCategory = categoryRepository.save(category);
                taskCategories.add(existingCategory);
            }
            existingCategory.setTasks(new HashSet<>());
            taskCategories.add(existingCategory);
        });
        task.setCategories(taskCategories);
        Task savedTask= taskRepository.save(task);
        return new ResponseEntity<Task>(savedTask, HttpStatus.CREATED);
    }

    @GetMapping("user/{id}/tasks")
    public List<Task> userTasks(@PathVariable("id") Long userId){
        logger.info("Task for user id {}" ,userId);
        return taskRepository.findByUserId(userId);
    }
}
