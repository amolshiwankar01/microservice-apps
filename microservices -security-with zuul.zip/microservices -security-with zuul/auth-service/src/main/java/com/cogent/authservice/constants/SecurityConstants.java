package com.cogent.authservice.constants;

/**
 * @author smriti on 6/27/19
 */
public class SecurityConstants {

    public static final String AUTHORIZATION_HEADER = "Authorization";
    public static final String BEARER_PREFIX = "Bearer";
}
