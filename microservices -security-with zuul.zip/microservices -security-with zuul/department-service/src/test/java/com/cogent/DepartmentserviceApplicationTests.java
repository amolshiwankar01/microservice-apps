package com.cogent;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author Sauravi
 */

@RunWith(SpringRunner.class)
@SpringBootTest
public class DepartmentserviceApplicationTests {

    @Test
    public void contextLoads() {
    }

}
